<!DOCTYPE html>
<html lang="en-us">
  <head>
    <title>WebSockets Wasm Doom</title>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="romero.css" />
    <meta name="viewport" content="minimal-ui, width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta property="og:title" content="Multiplayer WebSockets Doom" />
    <meta property="og:description" content="Multiplayer Doom on Cloudflare Workers" />
    <meta property="og:url" content="https://silentspacemarine.com" />
    <meta property="og:image" content="https://silentspacemarine.com/share.png" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:site" content="@cloudflare" />
    <meta name="twitter:description" content="Multiplayer Doom on Cloudflare Workers" />
    <meta name="twitter:image" content="https://silentspacemarine.com/share.png" />
  </head>
  <body class="noselect">
    <div id="container">
      <div id="mobile">
        <h1>For a better mobile experience, click "Hide Toolbar" in the URL toolbar</h1>
        <img src="hidetoolbar.png" />
      </div>
      <div id="monitor">
        <div id="monitorscreen">
          <canvas
            id="canvas"
            oncontextmenu="event.preventDefault()"
            tabindex="-1"
          ></canvas>
          <div id="menu">
            <div id="logo" class="vspace" style="display:none"></div>
            <div id="buttons" style="display:none">
              <a class="btn grey" id="multiplayer">Start Multiplayer</a>
              <a class="btn grey" id="solo">Play Solo</a>
            </div>
            <div id="text" style="display:none">
              <h1>This is a WebAssembly Doom Port With</h1>
              <h1><span class="h">Multiplayer</span> support running on top of Cloudflare's Edge Network</h1>
              <h1>Using <a target=_new href="https://developers.cloudflare.com/workers/" class="h">Workers</a>, <a target=_new href="https://developers.cloudflare.com/workers/runtime-apis/websockets" class="h">Websockets</a> and <a target=_new href="https://developers.cloudflare.com/workers/runtime-apis/durable-objects" class="h">Durable Objects</a></h1>
              <h1/>
                <h1><a href="https://blog.cloudflare.com/doom-multiplayer-workers">Read More About This Cloudflare Experiment</a></h1>
            </div>
          </div>
        </div>
        <div id="footer" class="writer"></div>
      </div>
    </div>
    <div id="joystick1"></div>
    <div id="joystick2"></div>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.8/clipboard.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/nipplejs/0.9.0/nipplejs.js"></script>
    <script type="text/javascript" src="carmack.js"></script>
    <script type="text/javascript" src="websockets-doom.js"></script>
    <script defer src='https://static.cloudflareinsights.com/beacon.min.js' data-cf-beacon='{"token": "5806d7916dd84a4199a061921ecc53ed"}'></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-FRH39ZYGGV"></script>
    <script>window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'G-FRH39ZYGGV'); </script>
  </body>
</html>
